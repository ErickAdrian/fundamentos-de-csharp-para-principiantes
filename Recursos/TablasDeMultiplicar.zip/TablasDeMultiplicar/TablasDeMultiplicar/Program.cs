﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TablasDeMultiplicar
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingresa un número: ");
            string numero = Console.ReadLine();
            int num = int.Parse(numero);
            if (num >= 1 && num <= 10)
            {
                Console.WriteLine("La tabla de multiplicar de {0} es: ", num);
                for (int i = 1; i <= 10; i++)
                {
                    int resultado = num * i;
                    Console.WriteLine("{0} x {1} = {2}", num, i, resultado);
                }
            }
            else
            {
                Console.WriteLine("El número ingresado debe estar entre 1 y 10");
            }
        }
    }
}
