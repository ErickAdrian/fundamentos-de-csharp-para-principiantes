﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TiposReferenciaVsTiposValor
{
    class PuntoRef
    {
        public int X { get; set; }
        public int Y { get; set; }

        public PuntoRef(int x, int y)
        {
            X = x;
            Y = y;
        }
    }
}
