﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Variables
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero = 10;
            int resultado = numero * 5;
            Console.WriteLine("{0}", resultado);

            int suma = 8 + 20;
            Console.WriteLine(suma);

            string cadena = "Este es un texto";
            Console.WriteLine(cadena);
        }
    }
}
