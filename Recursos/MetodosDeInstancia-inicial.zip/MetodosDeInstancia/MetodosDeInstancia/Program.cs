﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetodosDeInstancia
{
    /// <summary>
    /// Métodos de instancia
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {            
        }
    }
}
